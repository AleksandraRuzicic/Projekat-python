# from qgis.PyQt5.QtCore import import QVariant - ukoliko je standalone

# kreira se lejer 
lejer = QgsVectorLayer('Point', 'privremene_tacke', 'memory')
priv = lejer.dataProvider()

# dodavanje atributa
priv.addAttributes(
[QgsField('naziv', QVariant.String),
QgsField('godine', QVariant.Int),
QgsField('velicina', QVariant.Double)]
)

lejer.updateFields() # obavestava vektorski lejer da azurira promene od provajdera

# dodavanje feature-a
feat = QgsFeature()
feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(7367413,4940679)))
feat.setAttributes(['Prob', 2, 0.3])
priv.addFeatures([feat])

# azurira obim lejera kada su dodati novi feature-i
# posto se promena obima provajdera ne odrazava direktno na lejer
lejer.updateExtents 

print('fields: ', len(priv.fields()))
print('features: ', priv.featureCount())
e = lejer.extent()
print('obim: ', e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())

# vrsi iteraciju nad feature-ima
features = lejer.getFeatures()
for feat in features:
    print('F: ', feat.id(), feat.attributes(), feat.geometry().asPoint())






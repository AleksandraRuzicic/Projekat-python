'''from qgis.core import (
  QgsProject,
  QgsSettings,
  QgsVectorLayer
)'''             # ukoliko je standaloneDayName

# cuva podesavanja na globalnom nivou (vezano za korisnika koji koristi kompjuter)
# npr: velicina glavnog prozora..

s = QgsSettings()
#print(s.allKeys())

def sacuvaj():
    s = QgsSettings()
    s.setValue("moj_plugin/moj_tekst", "GIS programiranje")
    s.setValue("moj_plugin/moj_celobrojni",  9)
    s.setValue("moj_plugin/moj_realni", 3.25)
    s.setValue("qgis/digitizing/default_snapping_tolerance_unit", "snepovanje", 2)
    
def procitaj():
    s = QgsSettings()
    moj_tekst = s.value("moj_plugin/moj_tekst", "GIS Programiranje")
    moj_celobrojni  = s.value("moj_plugin/moj_celobrojni", 9)
    moj_realni = s.value("moj_plugin/moj_realni", 3.25)
    nepostojeci = s.value("moj_plugin/nepostojeci", None)
    print(moj_tekst)
    print(moj_celobrojni)
    print(moj_realni)
    print(nepostojeci)
    
sacuvaj()
procitaj()


projekat = QgsProject.instance()

# cuva vrednosti
projekat.writeEntry("moj_plugin", "moj_tekst", "GIS Prog")
projekat.writeEntry("moj_plugin", "moj_celobrojni", 9)
projekat.writeEntryDouble("moj_plugin", "moj_realni", 3.25)
projekat.writeEntryBool("moj_plugin", "moja_bulova_algebra", True)

# cita vrednosti (vraca torku sa vrednostima, i Bulov status
# koji govori da li se vracena vrednost moze konvertovati u njen tip,
# odnosno iz stringa, celobrojnog broja, realnog broja i Bulovog izraza

moj_tekst, type_conversion_ok = projekat.readEntry("moj_plugin", "moj_tekst", "GIS Prog")
moj_celobrojni, type_conversion_ok = projekat.readNumEntry("moj_plugin", "moj_celobrojni", 9)
moj_realni, type_conversion_ok = projekat.readDoubleEntry("moj_plugin", "moj_realni", 3.25)
moja_bulova_algebra, type_conversion_ok = projekat.readBoolEntry("moj_plugin", "moja_bulova_algebra", True)

lejer = QgsProject.instance().mapLayersByName("ZPD_")[0]
# cuva vrednost za odredjeni lejer
lejer.setCustomProperty('moj_tekst', 'Zasticena prirodna dobra na teritoriji opstina Ub i lajkovac')
# ponovo cita vrednost; drugi argument vraca 
tekst = lejer.customProperty('moj_tekst', 'nema_teksta')

print('-----------------------------------------')
print(tekst)







  
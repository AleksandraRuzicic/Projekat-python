lejer = iface.activeLayer()

# vrsi iteraciju nad podskupom feature-a
# unutar odredjenog prostora
podrucjeInteresa = QgsRectangle(7409215,4912300, 7439971,4938422)
request = QgsFeatureRequest().setFilterRect(podrucjeInteresa)

for feature in lejer.getFeatures(request):
    if feature[5] < 100.0:
        print('Povrsina poligona je manja od 100km kvadratnih')
    else:
        print('Povrsina poligona je veca od 100km kvadratnih')

# moguce je postaviti limit koliko feature-a
# zelimo da bude vraceno
request.setLimit(6)
for feature in lejer.getFeatures(request):
    print(feature)
    

# ukoliko zelimo da izvrsimo iteraciju i filtriranje na osnovu
# odredjenog atributa, tu mozemo iskoristimo QgsExpression objekat
# i da ga prosledimo QgsFeatureRequest konstruktoru
izraz = QgsExpression('br_st_2002 > 30000')
request = QgsFeatureRequest(izraz)

for feature in lejer.getFeatures(request):
    print(feature[4])
    
# jos neke korisne metode, namerno stavljene kao varijable
# vraca samo izabrane atribute, kako bi se ubrzao zahtev
x = request.setSubsetOfAttributes([1,6])

# drugi nacin
y = request.setSubsetOfAttributes(['OpisStari', 'povrsina'], lejer.fields())

# ne vraca objekte geometrije, kako bi se dodatno ubrzao zahtev
z = request.setFlags(QgsFeatureRequest.NoGeometry)

# vraca samo feature sa specificno navedenim ID
c = request.setFilterFid(9)

# moguce je odredjene opcije povezati i iskoristiti istovremeno
request.setFilterRect(podrucjeInteresa).setFlags(QgsFeatureRequest.NoGeometry).setFilterFid(1). \
setSubsetOfAttributes([1,6])

for feature in lejer.getFeatures(request):
    print(feature[1] + ' ' + str(feature[6]))
    
    
    
    
    

    
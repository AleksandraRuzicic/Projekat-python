# korisceni lejer: ZPD_
lejer = iface.activeLayer()

# proverava da li je odredjena funkcija podrzana
caps = lejer.dataProvider().capabilities()

if caps and QgsVectorDataProvider.AddAttributes:
    print('Lejer podrzava dodavanje atributa!')

# Proverava sve moguce funkcije lejera    
caps_string = lejer.dataProvider().capabilitiesString()
print(caps_string)


# dodavanje featurea
if caps and QgsVectorDataProvider.AddFeatures:
    feat = QgsFeature(lejer.fields())
    feat.setAttribute(0, 1)
    feat.setAttribute(1, 'Dva hrasta')
    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(7436277,4905239)))
    (res, outFeats) = lejer.dataProvider().addFeatures([feat])

# brisanje featurea
#if caps and QgsVectorDataProvider.DeleteFeatures:
    #res = lejer.dataProvider().deleteFeatures([2,3])
# res

# Menjanje featurea (geometrije ili atributa)
# obratiti paznju na to koji je FID od featurea
#fid = 3 - postoji mogucnost da je doslo do promene FIDa

#if caps and QgsVectorDataProvider.ChangeAttributeValues:
    #atributi = {0 : 4, 1: 'Stablo breze'}
    #lejer.dataProvider().changeAttributeValues({fid : atributi})












import random
from time import sleep

'''from qgis.core import (
    QgsApplication, QgsTask, QgsMessageLog,
    )'''  # ukoliko je standalone
    
MESSAGE_CATEGORY = 'RandomIntegerSumTask'

class RandomIntegerSumTask(QgsTask):
    # pokazuje kako mozemo da napravimo podklasu od QgsTask klase
    
    def __init__(self, description, trajanje):
        super().__init__(description, QgsTask.CanCancel)
        self.trajanje = trajanje
        self.ukupno = 0
        self.iteracije = 0
        self.izuzetak = None
    
    def run(self):
        # ubacuju se narednjenja koja zelimo da budu izvrsena
        # trebalo bi s vremena na vreme testirati, pomocu isCanceled() metode
        # kako bi se na vreme program prekinuo, ukoliko je doslo do greske
        # metod mora da vrati True ili False
        # podizanje izuzetaka (exception-a) ce dovesti do prestanka rada QGIS-a
        QgsMessageLog.logMessage('Task zapocet: {}'.format(self.description()), MESSAGE_CATEGORY, Qgis.Info)
        wait_time = self.trajanje/100
        for i in range(100):
            sleep(wait_time)
            # setProgress se koristi da bi se prijavio napredak
            task.setProgress(1)
            randomint = random.randint(0, 500)
            self.ukupno += randomint
            self.iteracije += 1
            # proverava task.isCanceled() kako bi postupio sa prekidanjem
            if self.isCanceled():
                return False
            # simulira izuzetke, da bi se prikazalo kako se prekida task
            if randomint == 54:
                # Ne podizi Exception('Losa vrednost')
                # ovo bi dovelo do prestanka rada QGIS-a
                self.izuzetak = Exception('Losa Vrednost!')
                return False
        return True
    
    def zavrsen(self, rezultat):
        # automatski se pokrece, cim se task uspesno zavrsi.
        # ovde se moze ubaciti sve sto zelimo da bude izvrseno
        # nakon izvrsenja taska
        # velika razlika je sto se uvek poziva iz main threada, 
        # pa je iz tog razloga moguce izvoditi razlicite GUI operacije
        # i podizanje izuzetaka (exception-a)
        # rezultat je povratna vrednost iz self.pokreni
        if rezultat:
            QgsMessageLog.LogMessage(
            'Random task "{}" izvrsen\n'\
            'Random ukupno "{}" (sa ukupnim brojem {} iteracija)'.format(
            self.description(),
            self.ukupno,
            self.iteracije),
            MESSAGE_CATEGORY, Qgis.Success)
        else:
            if self.izuzetak is None:
                QgsMessageLog.logMessage(
                'Random task "{}" nije uspeo, ali bez podizanja izuzetka'\
                '(task je verovatno prekinut od strane korisnika)'.format(
                self.description()), MESSAGE_CATEGORY, Qgis.Warning)
            else:
                QgsMessageLog.logMessage(
                'Random task "{}" izuzetak: {}.'.format(
                self.description(), self.izuzetak),
                MESSAGE_CATEGORY, Qgis.Critical)
                raise self.izuzetak
        
    def prekini(self):
        QgsMessageLog.logMessage(
        'Random task "{}" je prekinut'.format(self.description()),
        MESSAGE_CATEGORY, Qgis.Info)
        super().cancel()
            
        
        
dugacki_task = RandomIntegerSumTask('duza potrosnja procesora', 25)
kratki_task = RandomIntegerSumTask('kraca potrosnja procesora', 10)
mini_task = RandomIntegerSumTask('minijaturna potrosnja procesora', 5)
dugacki_podtask = RandomIntegerSumTask('podtask duze potrosnje procesora', 13)
kratki_podtask = RandomIntegerSumTask('podtask krace potrosnje procesora', 7)
najkraci_podtask = RandomIntegerSumTask('najkraci podtask potrosnje procesora', 3)


# dodaje podtask kratkom tasku, koji mora biti pokrenut
# nakon sto su se mini i dugacki task zavrsili
kratki_task.addSubTask(kratki_podtask, [mini_task, dugacki_task])

# dodaje podtask dugackom tasku, koji mora biti 
# pokrenut pre "roditeljskog" (parent) taska
dugacki_task.addSubTask(dugacki_podtask, [], QgsTask.ParentDependsOnSubTask)

# dodaje podtask dugackom tasku
dugacki_task.addSubTask(najkraci_podtask)

QgsApplication.taskManager().addTask(dugacki_task)
QgsApplication.taskManager().addTask(kratki_task)
QgsApplication.taskManager().addTask(mini_task)


















        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
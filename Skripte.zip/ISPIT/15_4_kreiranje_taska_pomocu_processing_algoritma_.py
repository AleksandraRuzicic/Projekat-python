from functools import partial
'''from qgis.core import (QgsTaskManager, QgsMessageLog,
                       QgsProcessingAlgRunnerTask, QgsApplication,
                       QgsProcessingContext, QgsProcessingFeedback,
                       QgsProject)'''  # ukoliko je standalone
                       


# kreira 5000 nasumicno rasporedjenih tacaka unutar izabranog lejera


lejer = QgsProject.instance().mapLayersByName('O Ub i Lajkovac')[0]
MESSAGE_CATEGORY = 'AlgRunnerTask'

def task_zavrsen(context, uspesno, results):
    if not uspesno:
        QgsMessageLog.logMessage('Task nije izvrsen', MESAGE_CATEGORY, Qgis.Warning)
    
    # takeMapLejer prebacuje vlasnistvo nad lejerom, 
    # pa je onda moguce dodati ga u projekat i dodeliti mu
    # vlasnistvo od projekta. U suprotnom, doslo bi do pucanja programa
    izlazni_lejer = context.getMapLayer(results['OUTPUT'])
    if izlazni_lejer and izlazni_lejer.isValid():
        QgsProject.instance().addMapLayer(context.takeResultLayer(izlazni_lejer.id()))

algoritam = QgsApplication.processingRegistry().algorithmById('qgis:randompointsinlayerbounds')
context = QgsProcessingContext()
feedback = QgsProcessingFeedback()
parametri = {
'INPUT': lejer,
'POINTS_NUMBER': 5000,
'TARGET_CRS': 'EPSG:3035',
'OUTPUT': 'memory:RandomTacke'
}

task = QgsProcessingAlgRunnerTask(algoritam, parametri, context, feedback)
task.executed.connect(partial(task_zavrsen, context))
QgsApplication.taskManager().addTask(task)










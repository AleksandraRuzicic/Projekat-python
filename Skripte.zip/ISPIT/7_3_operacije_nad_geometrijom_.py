# korisceni lejer = O Ub i Lajkovac CLC copy

lejer = QgsProject.instance().mapLayersByName('O Ub i Lajkovac CLC copy')[0]
# moze i preko iface.activeLayer()

# filtrira namenu zemljista kojima broj pocinje sa '3',
# zatim izvlaci njihove feature-e
upit = '"code_18" LIKE \'3%\''
features = lejer.getFeatures(QgsFeatureRequest().setFilterExpression(upit))

# vrsi iteraciju nad feature-ima, i izvrsava 
# geometrijsku komputaciju i stampa rezultate
for f in features:
    geom = f.geometry()
    naziv = f.attribute('opstina_la')
    print(naziv)
    print('Povrsina (km_2): ', geom.area()/1000000)
    print('Duzina (km): ', geom.length()/1000)
    
print('-----------------------------------------')

# alternativni nacin
# stampa kod od elipsoida koji se koristi
# print(QgsProject.instance().ellipsoid())
# stampa sve elipsoide po njihovom kodu
# print(QgsEllipsoidUtils.acronyms())
'''d = QgsDistanceArea()
d.setEllipsoid('EPSG:6316')

for f in features:
    geom = f.geometry()
    naziv = f.attribute('opstina_la')
    print(naziv)
    print('Duzina (km): ', d.measurePerimeter(geom)/1000)
    print('Povrsina (km_2): ', d.measureArea(geom)/1000000)'''

    
    
import os
#from qgis.core import(QgsVectorLayer) - ukoliko je standalone

#putanja do gpkg
putanja_do_puteva = os.path.join(QgsApplication.pkgDataPath(), 'resources', 'data', 'C:/Users/Sandra/Documents/MasterGIS/1 Upravljanje GIS projektima/Projekat/QGIS-projekat/O Ub i Lajkovac putevi_gpkg.gpkg')

vlayer = QgsVectorLayer(putanja_do_puteva, 'O Ub i Lajkovac putevi_gpkg', 'ogr')

if not vlayer.isValid():
    print("Lejer ne moze da se ucita.")
else:
    QgsProject.instance().addMapLayer(vlayer)


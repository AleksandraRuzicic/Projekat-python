# korisceni lejer ZPD_
lejer = iface.activeLayer()

kategorizovani_renderer = QgsCategorizedSymbolRenderer()
# Dodaje par kategorija
kat1 = QgsRendererCategory('1', QgsMarkerSymbol(), 'kategorija 1')
kat2 = QgsRendererCategory('2', QgsMarkerSymbol(), 'kategorija 2')
kat3 = QgsRendererCategory('3', QgsMarkerSymbol(), 'kategorija 3')

# kreiranje simbola za svaku kategoriju
simbol_1 = QgsMarkerSymbol.createSimple({'name': 'diamond', 'color': 'purple'})
kat1.setSymbol(simbol_1)

simbol_2 = QgsMarkerSymbol.createSimple({'name': 'square', 'color': 'yellow'})
kat2.setSymbol(simbol_2)

simbol_3 = QgsMarkerSymbol.createSimple({'name': 'triangle', 'color': 'orange'})
kat3.setSymbol(simbol_3)

# dodavanje kategorija rendereru
kategorizovani_renderer.addCategory(kat1)
kategorizovani_renderer.addCategory(kat2)
kategorizovani_renderer.addCategory(kat3)

for kat in kategorizovani_renderer.categories():
    print('{}: {} :: {}'.format(kat.value(), kat.label(), kat.symbol()))

kategorizovani_renderer.setClassAttribute('kategorije')
lejer.setRenderer(kategorizovani_renderer)
lejer.triggerRepaint()
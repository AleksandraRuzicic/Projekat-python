import os #potrebno i u QGIS-u
# from qgis.core import (QgsVectorLayer) - potrebno u standalone

# Uzima lejer na toj lokaciji
putanja_do_CLC = ("C:/Users/Sandra/Documents/MasterGIS/1 Upravljanje GIS projektima/Projekat/QGIS-projekat/O Ub i Lajkovac CLC.shp")

# Format je:
# vlayer = QgsVectorLayer(data_source, layer_name, provider_name)
vlayer = QgsVectorLayer(putanja_do_CLC, 'O Ub i Lajkovac CLC', 'ogr')

# Proverava da li je lejer uspesno ucitan
if not vlayer.isValid():
    print('Lejer ne moze da se ucita.')
else:
    QgsProject.instance().addMapLayer(vlayer)

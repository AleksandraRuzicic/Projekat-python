# koriscenje prostornih indeksa
# vise o njima na https://postgis.net/workshops/postgis-intro/indexing.html

# korisceni lejer = O Ub i Lajkovac CLC
lejer = iface.activeLayer()
feat = QgsFeature(lejer.fields())


# instanciranje objekta QgsSpatialIndex
indeks = QgsSpatialIndex(lejer.getFeatures())
# drugi nacin
# index = QgsSpatialIndex()
# index.addFeature(feat)


# vraca listu sa FID-ovima 5 najblizih feature-a
najblizi = indeks.nearestNeighbor(QgsPointXY(7368081.12,4940102.00), 5)
print(najblizi)

# vraca listu FID-ova od feature-a koji seku dati pravougaonik
intersect = indeks.intersects(QgsRectangle(7366985.16,4941546.15, 7367823.57,4942175.81))
print(intersect)

# moguce je koristiti i KDBush spatial index
# vise o njemu na https://qgis.org/api/3.4/classQgsSpatialIndexKDBush.html


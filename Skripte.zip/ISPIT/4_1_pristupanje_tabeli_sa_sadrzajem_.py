# daje listu lejera pomocu komprhenzije liste
l = [layer.name() for layer in QgsProject.instance().mapLayers().values()]
# recnik sa key = nazivom lejera i value = objektom lejera
layers_list = {}
for l in QgsProject.instance().mapLayers().values():
  layers_list[l.name()] = l

print(layers_list)

# Takodje je moguce izvrsiti selekciju konkretnog lejera
# pomocu njegovog naziva ([0] se koristi kako bi se izabrao prvi lejer
# sa navedenim nazivom, posto se na ovaj nacin obuhvataju svi lejeri sa
# unetim nazivom

putevi = QgsProject.instance().mapLayersByName('O Ub i Lajkovac putevi')[0]
print(putevi.name())
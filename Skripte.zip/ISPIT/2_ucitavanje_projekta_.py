# Ukoliko se skripta pokrece izvan QGIS-a, potrebno je importovati
# qgis i PyQT klase koje ce se koristiti
# from qgis.core import QgsProject

# Instanciranje projekta
project = QgsProject.instance()

# Ucitavanje projekta
project.read('C:/Users/Sandra/Documents/MasterGIS/1 Upravljanje GIS projektima/Projekat/QGIS-projekat/Projekat.qgz')

# Ukoliko menjamo nesto u projektu, uvek mozemo da to da sacuvamo pod istim imenom
project.write()
# Ili pod razlicitim
project.write('C:/Users/Sandra/Documents/MasterGIS/1 Upravljanje GIS projektima/Projekat/QGIS-projekat/Promena.qgz')

# Menja lose "putanje", u slucaju da doslo do promene lokacije lejera, promene adrese od hosta baze podataka...
'''def my_processor(path):
    return path.replace('host=10.1.1.115', 'host=10.1.1.116')

QgsPathResolver.setPathPreprocessor(my_processor)'''
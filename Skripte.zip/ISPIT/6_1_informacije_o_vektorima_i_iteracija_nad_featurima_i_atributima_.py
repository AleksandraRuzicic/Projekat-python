# upotreba vektorskih lejera, vecinom se koristi QgsVectorLayer klasa

vektor = QgsVectorLayer('C:/Users/Sandra/Documents/MasterGIS/1 Upravljanje GIS projektima/Projekat/QGIS-projekat/O Ub i Lajkovac CLC.shp', 'O Ub i Lajkovac CLC', 'ogr')
# QgsProject.instance().addMapLayer(vektor) - ukoliko je potrebno da se prikaze na mapi

# izlistava atribute lejera i njihove tipove
#for field in vektor.fields():
    #print(field.name(), field.typeName())

lejer = iface.activeLayer()
features = lejer.getFeatures()

for feature in features:
    # vraca svaki feature (tacku, liniju ili poligon tog lejera)
    # zajedno sa njegovom geometrijom i atributima
    print('Feature ID: ', feature.id())
    geom = feature.geometry()
    geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
    if geom.type() == QgsWkbTypes.PointGeometry:
        # tip geometrije moze da ima vise tipova
        if geomSingleType:
            x = geom.asPoint()
            print('Tacka: ', x)
        else:
            x = geom.asMultiPoint()
            print('MultiTacka: ', x)
    elif geom.type() == QgsWkbTypes.LineGeometry:
        if geomSingleType:
            x = geom.asPolyline()
            print('Linija: ', x, 'duzina: ', geom.length())
        else:
            x = geom.asMultiPolyline()
            print('MultiLinija: ', x, 'duzina: ', geom.length())
    elif geom.type() == QgsWkbTypes.PolygonGeometry:
        if geomSingleType:
            x = geom.asPolygon()
            print('Poligon: ', x, 'povrsina: ', geom.area())
        else:
            x = geom.asMultiPolygon()
            print('MultiPoligon: ', x, 'povrsina: ', geom.area())
    else:
        print('Geometrija ne postoji ili nije u redu')
    # vraca atribute kao listu, koja sadrzi sve vrednosti tog atributa
    atributi = feature.attributes()
    print(atributi)
    # kako ne bi izlistao za sve atribute, prekida se skripta sa break
    # ukoliko se zeli da se vide sve vrednosti za sve atribute, ukloniti break
    # ukoliko 
    break










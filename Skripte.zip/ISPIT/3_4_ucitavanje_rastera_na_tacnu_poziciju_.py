
put_do_rastera = 'C:/Users/Sandra/Documents/MasterGIS/1 Upravljanje GIS projektima/Projekat/QGIS-projekat/DEM Ub i Lajkovac.tif'

rlayer = QgsRasterLayer(put_do_rastera, 'DEM')

# Prvo se dodaje lejer, bez "pokazivanja"
QgsProject.instance().addMapLayer(rlayer, False)
# Pristupa se "stablu" lejera koji je na vrhu projekta
layerTree = iface.layerTreeCanvasBridge().rootGroup()
# Pozicija se definise kao prvi argument (-1, za poslednje mesto)
layerTree.insertChildNode(1, QgsLayerTreeLayer(rlayer))


# Ukoliko zelimo da uklonimo lejer
# QgsProject.instance().removeMapLayer(rlayer.id())

# Ukoliko zelimo da izlistamo ucitana lejere i njihove ID-e
# QgsProject.instance().mapLayers()
from qgis.PyQt import QtGui


# korisceni lejer: ZPD_
lejer = iface.activeLayer()
atribut = 'nm_visina'
opseg = []
prozirnost = 2
# kreira se prvi simbol i opseg
min = 50
max = 100.0
naziv = '50-100'
boja = QtGui.QColor('#ff7d7d')
prvi_simbol = QgsSymbol.defaultSymbol(lejer.geometryType())
prvi_simbol.setColor(boja)
prvi_simbol.setOpacity(prozirnost)
prvi_opseg = QgsRendererRange(min, max, prvi_simbol, naziv)
opseg.append(prvi_opseg)
# drugi simbol
min = 100.1
max = 200
naziv = '100-200'
boja = QtGui.QColor('#fc0303')
drugi_simbol = QgsSymbol.defaultSymbol(lejer.geometryType())
drugi_simbol.setColor(boja)
drugi_simbol.setOpacity(prozirnost)
drugi_opseg = QgsRendererRange(min, max, drugi_simbol, naziv)
opseg.append(drugi_opseg)

renderer = QgsGraduatedSymbolRenderer('', opseg)
metod_klasifikacije = QgsApplication.classificationMethodRegistry().method('EqualInterval')
renderer.setClassificationMethod(metod_klasifikacije)
renderer.setClassAttribute(atribut)

lejer.setRenderer(renderer)
lejer.triggerRepaint()












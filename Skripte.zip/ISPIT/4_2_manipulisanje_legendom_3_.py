root = QgsProject.instance().layerTreeRoot()
putevi = QgsProject.instance().mapLayersByName('O Ub i Lajkovac putevi')[0]


# pomeranje lejera u legendi
# kreiranje objekta QgsLayerTreeLayer iz puteva po njegovom ID-u
putevivektor = root.findLayer(putevi.id())
# klonira se prethodno kreirani objekat
putevivektorklon = putevivektor.clone()
# uzima "roditelja". Ukoliko je rezultat None,
# znaci da lejer nije ni u jednog grupi i vratice ''
roditelj = putevivektor.parent()
# pomera se klonirani lejer na vrh
roditelj.insertChildNode(0, putevivektorklon)
# uklanja se originalni lejer (putevivektor)
root.removeChildNode(putevivektor)

# prebacivanje lejera u odredjenu grupu (slican postupak kao kod pomeranja)
putevivektor = root.findLayer(putevi.id())
putevivektorklon = putevivektor.clone()
# kreiranje nove grupe
grupa1 = root.addGroup('Grupa')
roditelj = putevivektor.parent()
grupa1.insertChildNode(0, putevivektorklon)
roditelj.removeChildNode(putevivektor)

# jos neke metode, koje mogu da se koriste za menjanje
# grupa i lejera

# menjanje imena grupe
# node_group1.setName('Deponija_kriterijumi')

# ukljucivanje i iskljucivanje lejera
#node_group1.setItemVisibilityChecked(True)
#node_layer2.setItemVisibilityChecked(False)

# prosiruje i sakriva grupe u legendi
#node_group1.setExpanded(True)
#node_group1.SetExpanded(False)











import os

# Ucitava raster u projekat


#putanja do rastera (TIF)
put_do_rastera = 'C:/Users/Sandra/Documents/MasterGIS/1 Upravljanje GIS projektima/Projekat/QGIS-projekat/DEM Ub i Lajkovac.tif'

rlayer = QgsRasterLayer(put_do_rastera, 'DEM')

if not rlayer.isValid():
    print('Lejer ne moze da se ucita.')
else:
    QgsProject.instance().addMapLayer(rlayer)

# Drugi nacin
# iface.addRasterLayer(put_do_dema, 'DEM')